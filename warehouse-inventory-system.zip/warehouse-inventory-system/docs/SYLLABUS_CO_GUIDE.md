# Warehouse & Inventory Management System: Course Outcomes (CO1�CO6) Academic Guide

This document provides a comprehensive mapping of every syllabus topic to the codebase and database implementation of the **Warehouse & Inventory Management System**. Use this guide for project documentation, vivas, presentations, and examinations.

---

## Table of Contents
1. [CO1: Relational Database Engineering (MySQL Primary)](#co1-relational-database-engineering)
2. [CO2: Database Engineering (SQL vs NoSQL & Vector Foundations)](#co2-database-engineering)
3. [CO3: Backend API Engineering � FastAPI](#co3-backend-api-engineering)
4. [CO4: Multi-Framework Backend Engineering](#co4-multi-framework-backend-engineering)
5. [CO5: Microservices Engineering](#co5-microservices-engineering)
6. [CO6: Deployment, Observability & Delivery](#co6-deployment-observability--delivery)

---

## CO1: Relational Database Engineering

### 1. RDBMS Foundations & DBMS Architecture
- **Three-Schema Architecture**:
  1. *Physical/Internal Level*: MySQL InnoDB storage engine manages row storage in `.ibd` tablespace files with B+ Tree page indexing, buffer pool caching, and write-ahead redo logging (WAL) for crash resilience.
  2. *Conceptual/Logical Level*: Relational tables (`warehouses`, `products`, `warehouse_stock`, `stock_audit_log`) defined with primary keys, foreign keys, and normalized attributes.
  3. *External/View Level*: User-facing representations such as `product_stock_summary` and `category_stock_analytics` views that abstract multi-table joins.
- **Catalog Tools**: MySQL `INFORMATION_SCHEMA.TABLES` and `INFORMATION_SCHEMA.COLUMNS` store system metadata.

### 2. Entity-Relationship (ER) Modelling
- **Entities & Cardinalities**:
  - `Warehouse` (1) to `WarehouseStock` (N): A warehouse houses multiple stock records.
  - `Product` (1) to `WarehouseStock` (N): A product exists across multiple warehouses.
  - `Warehouse` (M) to `Product` (N): Many-to-many relationship resolved through associative table `warehouse_stock`.
  - `Product` / `Warehouse` to `StockAuditLog` (1 to N): Automated trigger audit entries.

```mermaid
erDiagram
    WAREHOUSES ||--o{ WAREHOUSE_STOCK : stores
    PRODUCTS ||--o{ WAREHOUSE_STOCK : tracked_in
    PRODUCTS ||--o{ STOCK_AUDIT_LOG : logs_changes
    WAREHOUSES ||--o{ STOCK_AUDIT_LOG : logs_changes

    WAREHOUSES {
        int id PK
        string name
        string location
        int capacity
    }

    PRODUCTS {
        int id PK
        string name
        string sku UK
        string category
        decimal price
        int quantity
        int reorder_level
    }

    WAREHOUSE_STOCK {
        int id PK
        int warehouse_id FK
        int product_id FK
        int quantity
    }

    STOCK_AUDIT_LOG {
        int id PK
        int product_id
        int warehouse_id
        int old_quantity
        int new_quantity
        string action
        timestamp changed_at
    }
```

### 3. Schema Design & Normalisation
- **First Normal Form (1NF)**: All attributes are atomic (no repeating groups or multi-valued fields).
- **Second Normal Form (2NF)**: 1NF satisfied and all non-key attributes are fully functionally dependent on the entire primary key (no partial dependencies).
- **Third Normal Form (3NF)**: 2NF satisfied and no transitive functional dependencies ($X \to Y$ where neither is a candidate key).
- **Integrity Constraints**:
  - `PRIMARY KEY`: Unique row identifiers on all tables.
  - `FOREIGN KEY ... ON DELETE CASCADE`: Ensures referential integrity between `warehouse_stock` and parent tables.
  - `UNIQUE (product_id, warehouse_id)`: Composite constraint preventing duplicate records for the same product in a warehouse.
  - `CHECK (price >= 0)` & `CHECK (quantity >= 0)`: Domain integrity constraints.
- **Index Design**:
  - B-Tree index on `products(category)` for rapid category filtering.
  - B-Tree index on `products(sku)` for $O(1)$ barcode/SKU lookups.
  - Foreign key indexes on `warehouse_stock(product_id)` and `warehouse_stock(warehouse_id)` to optimize relational joins.

### 4. SQL Advanced Querying
- **Aggregations & Grouping**:
  ```sql
  SELECT category, COUNT(DISTINCT id) AS total_items,
         SUM(quantity) AS total_units, ROUND(AVG(price), 2) AS avg_price
  FROM products GROUP BY category;
  ```
- **Window Functions (`DENSE_RANK() OVER`)**:
  ```sql
  SELECT name, category, price, quantity,
         DENSE_RANK() OVER (PARTITION BY category ORDER BY quantity DESC) AS category_rank
  FROM products;
  ```
- **Common Table Expressions (CTEs)**:
  ```sql
  WITH low_stock_cte AS (
      SELECT id, name, sku, category, reorder_level,
             (SELECT COALESCE(SUM(quantity), 0) FROM warehouse_stock WHERE product_id = p.id) AS stock
      FROM products p
  )
  SELECT *, (reorder_level - stock) AS deficit
  FROM low_stock_cte
  WHERE stock <= reorder_level;
  ```

### 5. Transactions & Stored Logic (ACID)
- **ACID Guarantees**:
  - **Atomicity**: Stored procedure `transfer_stock` executes both debit and credit within `START TRANSACTION ... COMMIT`; any failure rolls back all modifications via `DECLARE EXIT HANDLER FOR SQLEXCEPTION`.
  - **Consistency**: Prevents stock from dipping below zero via `CHECK (quantity >= 0)` and procedure validation.
  - **Isolation**: Uses `SELECT ... FOR UPDATE` pessimistic row locking under MySQL's `REPEATABLE READ` default isolation level to prevent lost updates.
  - **Durability**: InnoDB write-ahead redo logs ensure committed transactions survive server restarts.
- **Stored Procedure (`transfer_stock`)**: See [backend/schema.sql](file:///C:/Users/meghana/Desktop/DBMS/backend/schema.sql#L100-L150).
- **Trigger (`after_stock_update`)**: Automatically records stock fluctuations into `stock_audit_log`.

---

## CO2: Database Engineering

### SQL vs NoSQL Comparative Matrix
| Dimension | Relational (MySQL) | Document NoSQL (MongoDB) | Vector Database (pgvector / Chroma) |
|---|---|---|---|
| **Data Model** | Rigid Tables, Rows, Columns | Dynamic JSON / BSON Documents | High-dimensional Vector Embeddings |
| **Schema** | Explicit DDL, Enforced constraints | Dynamic, Schema-on-read | Fixed embedding dimension |
| **Consistency** | Strong ACID, Serializability | Tunable consistency (CAP Theorem) | Eventual / Approximate Search |
| **Scaling** | Vertical scaling, Read replicas | Horizontal sharding | Distributed vector indexing |
| **Use Case in Project** | Core inventory balances, transactions, audit trails | Rich dynamic product specs (IoT sensors, certifications) | Semantic natural language search ("quiet warehouse scanner") |

- **Polyglot Persistence Pattern**: Using MySQL for transactional reliability (ACID) and NoSQL/JSON document models for flexible product specifications.
- **Vector Search Foundations**: Embeddings encode semantic meaning into high-dimensional vector space. Similarity metrics include **Cosine Similarity** ($\cos(\theta) = \frac{A \cdot B}{\|A\| \|B\|}$) and Euclidean Distance ($L2$). Indexing algorithms like **HNSW** (Hierarchical Navigable Small World) enable Approximate Nearest Neighbor (ANN) search.

---

## CO3: Backend API Engineering � FastAPI

- **RESTful Architecture**: Clean HTTP verbs (`GET` for reading, `POST` for creation/execution, `DELETE` for removal), standard status codes (`200 OK`, `400 Bad Request`, `404 Not Found`, `500 Server Error`).
- **Pydantic Validation**: Automatic schema enforcement, type coercion, and error generation on inbound request payloads.
- **Dependency Injection**: `Depends(get_db)` manages database session lifecycles, ensuring connections are closed and returned to the pool after each request.
- **FastAPI Interactive Documentation**: Auto-generated Swagger UI (`/docs`) and ReDoc (`/redoc`) implementing the OpenAPI 3.0 specification.
- **Framework Comparison**:
  - *FastAPI*: Asynchronous ASGI, native Pydantic validation, fastest execution.
  - *Flask*: Lightweight WSGI microframework, flexible but lacks native async/OpenAPI.
  - *Django*: Full-stack batteries-included MVC, heavier overhead.

---

## CO4: Multi-Framework Backend Engineering

- **Architectural Thinking & Service Boundaries**:
  - Separation of Concerns: Core inventory transactions separated from event streams.
  - Service-Oriented Architecture (SOA): Services communicate through well-defined API contracts.
- **Spring Boot & Node.js Roles**:
  - Node.js / Express is ideal for non-blocking I/O, WebSockets, and real-time stock alert push notifications.
  - Spring Boot provides enterprise Java inversion of control (IoC), Spring Data JPA, and robust enterprise integrations.

---

## CO5: Microservices Engineering

- **Microservices Foundations**: Decomposing monolithic inventory into bounded contexts:
  1. *Inventory Service* (FastAPI + MySQL): Transactional stock ledger.
  2. *Activity & Audit Service* (Node.js / FastAPI): Event stream logging.
  3. *Notification Service*: Alerting warehouse managers on stock depletion.
- **Distributed Transactions & Saga Pattern**:
  - Traditional 2-Phase Commit (2PC) creates blocking locks across services.
  - The **Saga Pattern** manages distributed transactions through a sequence of local transactions with *Compensating Actions* (e.g. if payment fails after stock reservation, emit compensation event to release reserved inventory).

---

## CO6: Deployment, Observability & Delivery

- **Containerisation with Docker**: Packaging FastAPI, MySQL, and Nginx into isolated, reproducible containers using Dockerfile and Docker Compose.
- **Observability**: Health checking (`/`), structured JSON error logs, and Prometheus metrics readiness.
- **CI/CD Pipeline**: Automated GitHub Actions workflow for linting, testing, and security scanning on pull requests.
